# Write a shell script to scan two variables and to display their sum, mul, div, sub and modulo division.

clear
echo Input two Numbers:
read n1
read n2

echo n1 = $n1
echo n2 = $n2

echo Enter your choice from the following:
echo 1. Add
echo 2. Subtract
echo 3. Multiply
echo 4. Divide n1 by n2
echo 5. Modulo divide n1 by n2

read choice

switch(choice)
{
case 1: 
echo The addition of n1 and n2 is:
n=`expr $n1 \+ $n2`
echo $n

case 3:
echo The multiplication of n1 and n2 is:
n=`expr $n1 \* $n2`
echo $n

case 2:
echo The difference of n1 and n2 is:
m=`expr $n1 \- $n2`
echo $m

case 4:
echo Dividing n1 by n2 gives:
m=`expr $n1 \/ $n2`
echo $m

case 5:
echo Modulo Dividing n1 by n2 gives: 
m=`expr $n1 \% $n2`
echo $m
}

