while [ 1 ]
do
	echo Enter the Capital of Gujarat:
	read n
	if [ $n = "Gandhinagar" ]
		then 
			echo Correct Answer
			break
		else
			continue
	fi
done 
	


