nicknames=("aakanksha" "aaka" "baboo" "akku" "maggie" "lalli");
echo -n "Enter the nick name you want to search:  "
read string
search=`echo ${nicknames[*]} | grep "$string"`

if [ "${search}" != "" ]; then
  echo -n The list contains: $string 
else
  echo -n $string is not present in the list.
fi
echo 
