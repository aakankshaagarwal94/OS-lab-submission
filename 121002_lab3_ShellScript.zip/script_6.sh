echo  scanning and executing PWD
pwd
echo  scanning and executing progress...
whoami 
