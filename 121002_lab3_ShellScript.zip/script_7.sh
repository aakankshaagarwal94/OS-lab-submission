#Write a shell script which displays January if we enter Jan, Janu, Janua or January.(use of case)
#!/bin/bash

clear
read n
case $n in 
jan ) echo "January";;
janu ) echo "January";;
janua ) echo "January";;
january ) echo "January";;
esac


